

import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import classes from "../Navbar.module.css";

const ManageX = ({ handleClose, show }) => {
  return (
    <Modal show={show} onHide={handleClose} dialogClassName="modal-dialog modal-lg">
      <Modal.Header closeButton>
        <Modal.Title>Fast Scheduling</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <h1>Manage & Track Events</h1>
        <p>Easyliy Create and send invoce to get paid on
time.</p>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

const  Manages = () => {
  const [showModal, setShowModal] = useState(false);

  const handleCloseModal = () => setShowModal(false);
  const handleShowModal = () => setShowModal(true);

  return (
    <div>
     
     <h1 ><button className={classes.modelbtn} onClick={handleShowModal}>Manage & Track Events</button></h1> 
     <p>Easyliy Create and send invoce to get paid on
time</p>
      <ManageX show={showModal} handleClose={handleCloseModal} />
    </div>
  );
};
export default Manages;