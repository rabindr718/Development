import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
import classes from "../Navbar.module.css";
const handleCloseModal = () => setShowModal(false);
const handleShowModal = () => setShowModal(true);
const SchedulingModal = ({ handleClose, show }) => {
  const [showModal, setShowModal] = useState(false);

 
  return (
    <Modal
      show={show}
      onHide={handleClose}
      dialogClassName="modal-dialog modal-lg"
    >
      <Modal.Header closeButton>
        <Modal.Title>Fast Scheduling</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <h1>Fast Scheduling</h1>
        <p>Easily create and send invoices to get paid on time.</p>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

const Scheduling = () => {


  return (
    <div>
      <h1>
        <button className={classes.modelbtn} onClick={handleShowModal}>
          Fast Scheduling
        </button>
      </h1>
      <p>Easily create and send invoices to get paid on time.</p>
      <SchedulingModal show={showModal} handleClose={handleCloseModal} />
    </div>
  );
};

export default Scheduling;
