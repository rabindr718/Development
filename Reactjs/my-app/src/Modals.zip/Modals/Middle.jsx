import Powerful from "./Powerful";
import Professional from "./Profesional";
import SchedulingModal from "./Scheduling";
import Manages from "./Manages";
import FeedBack from "./FeedBack";
import classes from "../Navbar.module.css";

const Middle=()=>{
    return <div className={classes.middle}>
        <div className={classes.middleHead}><h1>Use Just Wedding for</h1></div>
        <Professional></Professional>
        <SchedulingModal></SchedulingModal>
        <Powerful></Powerful>
        <Manages></Manages>
        <FeedBack></FeedBack>
    </div>

}

export default Middle;